package net.osmangazi.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.Identifier;
import net.osmangazi.OsmanGaziMod;
import net.osmangazi.OsmanUnit;
import net.osmangazi.UnitDef;

public class OsmanRenderer extends HumanoidMobRenderer<OsmanUnit, OsmanRenderer.State, HumanoidModel<OsmanRenderer.State>> {
    public static class State extends HumanoidRenderState {
        public float scale = 1.0F;
    }

    private final Identifier texture;
    private final float scale;

    public OsmanRenderer(EntityRendererProvider.Context ctx, UnitDef def) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
        this.texture = Identifier.fromNamespaceAndPath(OsmanGaziMod.MODID, "textures/entity/" + def.id() + ".png");
        this.scale = def.scale();
    }

    @Override
    public State createRenderState() { return new State(); }

    @Override
    public void extractRenderState(OsmanUnit e, State s, float partial) {
        super.extractRenderState(e, s, partial);
        s.scale = scale;
    }

    @Override
    public Identifier getTextureLocation(State s) { return texture; }

    @Override
    protected void scale(State s, PoseStack ps) { ps.scale(s.scale, s.scale, s.scale); }
}
