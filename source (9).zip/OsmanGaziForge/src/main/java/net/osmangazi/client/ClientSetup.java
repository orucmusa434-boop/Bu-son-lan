package net.osmangazi.client;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.listener.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.osmangazi.ModEntities;
import net.osmangazi.OsmanGaziMod;
import net.osmangazi.OsmanHorse;
import net.osmangazi.UnitDef;

@Mod.EventBusSubscriber(modid = OsmanGaziMod.MODID, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        for (UnitDef def : UnitDef.ALL)
            e.registerEntityRenderer(ModEntities.type(def.id()), ctx -> new OsmanRenderer(ctx, def));
        for (OsmanHorse.HorseDef hd : OsmanHorse.ALL)
            e.registerEntityRenderer(ModEntities.horseObject(hd.id()).get(), OsmanHorseRenderer::new);
        e.registerEntityRenderer(ModEntities.CANNONBALL.get(), ThrownItemRenderer::new);
    }
}
